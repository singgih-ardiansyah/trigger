﻿<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="description" content="Trigger">
  <meta name="keywords" content="Trigger_Team">
  <meta name="apple-mobile-web-app-capable" content="yes">

  <title>Trigger</title>
  
  <link rel="shortcut icon" type="image/x-icon" href="<?= base_url('assets/') ?>img/KIR_Smega.png">
  
  <link rel="stylesheet" href="<?= base_url('assets/') ?>\plugin\bootstrap\css\bootstrap.min.css">
  <link rel="stylesheet" href="<?= base_url('assets/') ?>\css\color\default.css" id="color_theme">
  
  <!-- SweetAlert -->
  <link rel="stylesheet" href="<?= base_url('assets/') ?>plugin\sweetalert2\sweetalert2.min.css">
  <script src="<?= base_url('assets/') ?>plugin/sweetalert2/sweetalert2.all.min.js"></script>
  
  <link rel="stylesheet" href="<?= base_url('assets/') ?>\css\style.css">
</head>

<body data-spy="scroll" data-target="#navbar" data-offset="98">

  <div id="loading">
    <div class="load-circle"><span class="one"></span></div>
  </div>

  <header>
    <nav class="navbar header-nav navbar-expand-lg">
      <div class="container">
        <a class="navbar-brand" href="#">
          <img class="light-logo" src="<?= base_url('assets/') ?>img/logo-light.png" title="" alt="">
          <img class="dark-logo" src="<?= base_url('assets/') ?>img/logo.png" title="" alt="">
        </a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar" aria-controls="navbar" aria-expanded="false" aria-label="Toggle navigation">
            <span></span>
            <span></span>
            <span></span>
        </button>
        <div class="collapse navbar-collapse justify-content-end" id="navbar">
          <ul class="navbar-nav ml-auto align-items-center">
            <li><a class="nav-link" href="#home">Home</a></li>
            <li><a class="nav-link" href="#contact">Contact</a></li>
          </ul>
            <div>
              <img src="<?= base_url('assets/') ?>img/KIR_Smega.png" alt="KIR_Smega" width="30px">
              <img src="<?= base_url('assets/') ?>img/smkn1pbg.png" alt="SMKN 1 PURBALINGGA" width="40px">
            </div>
        </div>
      </div>
    </nav> 
  </header>

  <main>
    <section id="home" class="home-banner-03 theme-bg bg-effect-box">
      <div class="bg-effect bg-cover" style="background-image: url(<?= base_url('assets/') ?>img/banner-effect-6.svg);"></div>
      <div id="particles_effect" class="particles-effect"></div> </br></br>
      <div class="container">
        <div class="row align-items-center justify-content-center p-100px-tb sm-p-60px-b">
          <div class="col-lg-5 md-p-30px-tb " >
            <h5 class="white-color" class="mt-5">Singgih, Arisca, Dea</h5>
            <h1 class="font-alt white-color">Login Trigger</h1>
            <p class="white-color-light">SMK Negeri 1 Purbalingga</p>
            <?= $this->session->flashdata('login_message') ?>
            <div class="subscribe-block">
                <div class="card-block py-lg px-md">

                  <form id="loginForm" class="md-form form-light" role="form" action="<?= base_url('login') ?>" method="post">
                    <div class="row">
                      <div class="col-md-6 pr-2">
                        <div class="form-group">
                          <label for="inputUser" class="form-label">Username</label>
                          <div class="md-form-line-wrap">
                            <input id="inputUser" type="text" name="username" placeholder="Username" class="form-control" value="<?= set_value('username') ?>" autofocus>
                            <?= form_error('username', '<div class="text-light">', '</div>') ?>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6 pl-2">
                        <div class="form-group">
                          <label for="inputPassword" class="form-label">Password</label>
                          <div class="md-form-line-wrap">
                            <input id="inputPassword" type="password" name="password" placeholder="Password" class="form-control">
                            <?= form_error('password', '<div class="text-light">', '</div>') ?>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-12 mt-3">
                          <button type="submit" class="btn btn-block btn-light"><span class="btn-elem-wrap"><span class="text" style="color: darkblue">LOGIN</span></span></button>
                      </div>
                    </div>
                  </form>

                </div>
              <label>Powered by Kelompok Ilmiah Remaja SMKN 1 PURBALINGGA</label>
            </div>
          </div>
          <div class="col-lg-7 text-center p-200px-l">
            <img src="<?= base_url('assets/') ?>img/1perempatan.png" title="" alt="Traffic Light Integration System" >
          </div> 
        </div> 
      </div>
    </section>


    <section id="contact" class="section">
      <div class="container">
        <div class="row m-45px-b sm-m-25px-b">
          <div class="col-lg-5 col-md-10">
            <div class="section-title-01">
              <h2 class="dark-color font-alt">Kontak</h2>
            </div>
          </div>
        </div>

        <div class="row justify-content-center">
          <div class="col-lg-8 md-m-30px-b">
            <div class="contact-form">
                <h4 class="dark-color font-alt m-30px-b">Say Something</h4>
                <form class="contactform" method="post">
                    <div class="row">
                      <div class="col-md-6">
                        <div class="form-group">
                          <input id="name" name="name" type="text" placeholder="Name" class="validate form-control" required="">
                          <span class="input-focus-effect theme-bg"></span>
                        </div>
                        </div>
                        <div class="col-md-6">
                        <div class="form-group">
                          <input id="email" type="email" placeholder="Email" name="email" class="validate form-control" required="">
                          <span class="input-focus-effect theme-bg"></span>
                        </div>
                        </div>
                        <div class="col-md-12">
                        <div class="form-group">
                          <textarea id="message" placeholder="Your Comment" name="message" class="form-control" required=""></textarea>
                          <span class="input-focus-effect theme-bg"></span>
                        </div>
                      </div>
                        <div class="col-md-12">
                          <div class="send">
                            <button class="btn btn-theme" type="submit" name="send">send message</button>
                          </div>
                          <span class="output_message"></span>
                        </div>
                      </div>
                </form>
            </div>
          </div> 
          <div class="col-lg-4">
            <div class="contact-info">
                <i class="theme-color ti-location-pin"></i>
                <h6 class="dark-color font-alt"> Alamat</h6>
                <p>SMK NEGERI 1 PURBALINGGA</p>
            </div>
            <div class="contact-info">
              <i class="theme-color ti-mobile"></i>
              <h6 class="dark-color font-alt">Telepon</h6>
              <p>+62858 7620 5464<br></p>
            </div>
            <div class="contact-info">
                <i class="theme-color ti-email"></i>
                <h6 class="dark-color font-alt">Email</h6>
                <p>singgihard.tkj2@gmail.com</p>
            </div>
          </div>
        </div>
        
      </div> 
    </section>

  </main>
  <footer class="footer footer-dark">
    <div class="footer-copy">
      <div class="row">
        <div class="col-12">
          <p>All © Trigger_Team All Rights Reserved.</p>
        </div>
      </div> 
    </div>
  </footer>
  
  <script src="<?= base_url('assets/') ?>js/jquery-3.2.1.min.js"></script>
  <script src="<?= base_url('assets/') ?>js/jquery-migrate-3.0.0.min.js"></script>
  <script src="<?= base_url('assets/') ?>plugin/appear/jquery.appear.js"></script>
  <script src="<?= base_url('assets/') ?>plugin/bootstrap/js/popper.min.js"></script>
  <script src="<?= base_url('assets/') ?>plugin/bootstrap/js/bootstrap.js"></script>
  <script src="<?= base_url('assets/') ?>plugin/particles/particles.min.js"></script>
  <script src="<?= base_url('assets/') ?>plugin/particles/particles-app.js"></script>
  <script src="<?= base_url('assets/') ?>js/jquery.parallax-scroll.js"></script>
  <script src="<?= base_url('assets/') ?>js/custom.js"></script>

</body>
</html>