<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="description" content="Trigger">
<meta name="keywords" content="Trigger_Team">
<meta name="apple-mobile-web-app-capable" content="yes">

<title>Trigger</title>

<link rel="shortcut icon" type="image/x-icon" href="<?= base_url('assets/') ?>img/KIR_Smega.png">

<link rel="stylesheet" href="<?= base_url('assets/') ?>plugin/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="<?= base_url('assets/') ?>plugin/font-awesome/css/fontawesome-all.min.css">
<link rel="stylesheet" href="<?= base_url('assets/') ?>css/color/default.css" id="color_theme">
<link rel="stylesheet" href="<?= base_url('assets/') ?>css/style.css">
</head>

</body>
<main>
    <section id="home" class="home-banner-03 theme-bg bg-effect-box">
    <div class="bg-effect bg-cover" style="background-image: url(<?= base_url('assets/') ?>img/banner-effect-6.svg);"></div>
    <div id="particles_effect" class="particles-effect"></div>
    <div class="container">
        <div class="container" >
            <!-- FORM JUDUL -->
            <div class="row justify-content-center" >
            <div>
                <h1 class="font-alt white-color mt-4 mb-5">Traffic Light Integration System</h1>
            </div>
            </div>
            <div class="row justify-content-center mb-3">
                <h2 class="font-alt aqua-color">Daftar Lampu Lalu Lintas</h2>
            </div>
        </div>

        <section>
            <div class="container mt-5">
            <!-- Baris Pertama -->
            <div class="row justify-content-between">
                <?php foreach($triggers as $trigger): ?>
                <div class="col-md-5 bg-dark mb-4">
                    <div class="row biru-dark">
                        <div class="row no-gutters">
                            <div class="col-2 justify-content-center">
                                <button type="button" class="btn-dark biru-dark no-border ml-2" onclick="location.href = '<?= $trigger['url'] ?>'">
                                    <img src="<?= base_url('assets/') ?>img/Lokasi.png" alt="TrafficLight"> 
                                    <h6>Lokasi</h6>  
                                </button>
                            </div>
                            <div class="col-10 justify-content-center">
                                <button type="button" class="btn-dark biru-dark no-border" onclick="location.href = '<?= base_url('trigger/detail/') . $trigger['id'] ?>'">
                                    <h3><?= $trigger['location'] ?></h3>
                                    <?= $trigger['description'] ?>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach ?>
            </div>

        </section>

        <!-- KIR -->
        <div class="container mt-3">
            <div class="row justify-content-center">
                <img src="<?= base_url('assets/') ?>img/KIR_Smega.png" alt="Kelompok Ilmiah SMKN 1 Purbalingga" width="5%">
            </div>
            <div class="row justify-content-center">
                <h6>SMKN 1 Purbalingga</h6>
            </div>
        </div>

    </div>
    </section> 
</main>


<footer class="footer footer-dark">
    <div class="footer-copy">
        <div class="row">
        <div class="col-12">
            <p>All © Trigger_Team All Rights Reserved.</p>
        </div>
        </div> 
    </div>
    </footer>

<script src="<?= base_url('assets/') ?>js/jquery-3.2.1.min.js"></script>
<script src="<?= base_url('assets/') ?>js/jquery-migrate-3.0.0.min.js"></script>
<script src="<?= base_url('assets/') ?>js/jquery.parallax-scroll.js"></script>
<script src="<?= base_url('assets/') ?>plugin/appear/jquery.appear.js"></script>
<script src="<?= base_url('assets/') ?>plugin/bootstrap/js/popper.min.js"></script>
<script src="<?= base_url('assets/') ?>plugin/bootstrap/js/bootstrap.js"></script>
<script src="<?= base_url('assets/') ?>plugin/particles/particles.min.js"></script>
<script src="<?= base_url('assets/') ?>plugin/particles/particles-app.js"></script>
<script src="<?= base_url('assets/') ?>js/custom.js"></script>

</body>
</html>