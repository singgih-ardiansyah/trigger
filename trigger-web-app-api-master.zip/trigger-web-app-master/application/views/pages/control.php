<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="Trigger">
    <meta name="keywords" content="Trigger_Team">
    <meta name="apple-mobile-web-app-capable" content="yes">
    
    <title>Trigger</title>
    
    <link rel="shortcut icon" type="image/x-icon" href="<?= base_url('assets/') ?>img/KIR_Smega.png">
    
    <link rel="stylesheet" href="<?= base_url('assets/') ?>plugin/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?= base_url('assets/') ?>plugin/font-awesome/css/fontawesome-all.min.css">
    <link rel="stylesheet" href="<?= base_url('assets/') ?>css/color/default.css" id="color_theme">
    <link rel="stylesheet" href="<?= base_url('assets/') ?>css/style.css">
    
  </head>

  </body>
    <main>
      <section id="home" class="home-banner-03 theme-bg bg-effect-box">
        <div class="bg-effect bg-cover" style="background-image: url(<?= base_url('assets/') ?>img/banner-effect-6.svg);"></div>
        <div id="particles_effect" class="particles-effect"></div>
        
        <div class="container">
          <div class="container" >
              <!-- FORM JUDUL -->
              <div class="row justify-content-center" >
                <div>
                  <h1 class="font-alt white-color mt-3 mb-3"><?= $trigger['location'] ?></h1>
                </div>
              </div>
              <div class="row justify-content-center">
                <?php if($trigger['automation'] == 1): ?>
                  <h2 class="font-alt aqua-color">Mode Otomatisasi</h2>
                <?php else: ?>
                  <h2 class="font-alt aqua-color">Kontrol Manual</h2>
                <?php endif ?>
              </div>
          </div>

          <section>
            <div class="container mt-5">
              <div class="row justify-content-between">
                <?php if($trigger['automation'] == 1): ?>
                  <?php foreach($dirs as $dir): ?>
                    <div class="col-md-5 bg-dark mb-3">
                      <div class="row biru-dark">
                        <button type="button" class="col-12 btn-dark biru-dark no-border">
                          <div class="col-12 biru-dark1 p-1">
                            <h4><?= $dir['label'] ?></h4>
                          </div>
                          <div class="row no-gutters py-2">
                            <div class="col-3">
                                <img src="<?= base_url('assets/') ?>img/trafficlight.png" alt="TrafficLight">
                            </div>
                            <div class="col-9 justify-content-center">
                              <?php if($trigger['state_' . $dir['id']] == 'ramai'): ?>
                                <h3><?= $trigger['tauto_' . $dir['id']] / 1000 + $trigger['tramai'] / 1000 ?> Detik</h3>
                              <?php elseif($trigger['state_' . $dir['id']] == 'sepi'): ?>
                                <h3><?= $trigger['tauto_' . $dir['id']] / 1000 - $trigger['tsepi'] / 1000 ?> Detik</h3>
                              <?php else: ?>
                                <h3><?= $trigger['tauto_' . $dir['id']] / 1000 ?> Detik</h3>
                              <?php endif ?>
                              <h4><?= $trigger['state_' . $dir['id']] ?></h4>
                            </div>
                          </div>
                        </button>
                        <div class="col-12 mb-1">
                          <form action="<?= base_url('trigger/setTauto/' . $dir['id'] . '/') . $trigger['id'] ?>" method="post">
                            <div class="input-group">
                              <input type="number" class="form-control" name="tauto" placeholder="Masukkan waktu" aria-label="Masukkan waktu" aria-describedby="basic-addon2">
                              <div class="input-group-append">
                                <button class="btn btn-outline-secondary" type="submit">SET</button>
                              </div>
                            </div>
                          </form>
                        </div>
                      </div>
                    </div>
                  <?php endforeach ?>
                  <?php foreach($states as $state): ?>
                    <div class="col-md-5 bg-dark mb-3">
                      <div class="row biru-dark">
                        <button type="button" class="col-12 btn-dark biru-dark no-border">
                          <div class="col-12 biru-dark1 p-1">
                            <h4><?= $state['label'] ?></h4>
                          </div>
                          <div class="row no-gutters py-2">
                            <div class="col-3">
                                <img src="<?= base_url('assets/') ?>img/trafficlight.png" alt="TrafficLight">
                            </div>
                            <div class="col-9 justify-content-center">
                              <h3>
                                <?= $state['id'] == 'ramai' ? '+' : '-' ?>
                                <?= $trigger['t' . $state['id']] / 1000 ?> Detik
                              </h3>
                            </div>
                          </div>
                        </button>
                        <div class="col-12 mb-1">
                          <form action="<?= base_url('trigger/setSauto/' . $state['id'] . '/') . $trigger['id'] ?>" method="post">
                            <div class="input-group">
                              <input type="number" class="form-control" name="sauto" placeholder="Masukkan waktu" aria-label="Masukkan waktu" aria-describedby="basic-addon2">
                              <div class="input-group-append">
                                <button class="btn btn-outline-secondary" type="submit">SET</button>
                              </div>
                            </div>
                          </form>
                        </div>
                      </div>
                    </div>
                  <?php endforeach ?>
                <?php else: ?>
                  <?php foreach($dirs as $dir): ?>
                    <div class="col-md-5 bg-dark mb-3">
                      <div class="row biru-dark">
                        <button type="button" class="col-12 btn-dark biru-dark no-border">
                          <div class="col-12 biru-dark1 p-1">
                            <h4><?= $dir['label'] ?></h4>
                          </div>
                          <div class="row no-gutters py-2">
                            <div class="col-3">
                                <img src="<?= base_url('assets/') ?>img/trafficlight.png" alt="TrafficLight">
                            </div>
                            <div class="col-9 justify-content-center">
                              <h3><?= $trigger['time_' . $dir['id']] / 1000 ?> Detik</h3>
                              <h4><?= $trigger['state_' . $dir['id']] ?></h4>
                            </div>
                          </div>
                        </button>
                        <div class="col-12 mb-1">
                          <form action="<?= base_url('trigger/setTime/' . $dir['id'] . '/') . $trigger['id'] ?>" method="post">
                            <div class="input-group">
                              <input type="number" class="form-control" name="time" placeholder="Masukkan waktu" aria-label="Masukkan waktu" aria-describedby="basic-addon2">
                              <div class="input-group-append">
                                <button class="btn btn-outline-secondary" type="submit">SET</button>
                              </div>
                            </div>
                          </form>
                        </div>
                      </div>
                    </div>
                  <?php endforeach ?>
                <?php endif ?>
              </div>
            </div>
          </section>

          <!-- KIR -->
          <div class="container">
            <div class="row justify-content-center">
              <img src="<?= base_url('assets/') ?>img/KIR_Smega.png" alt="Kelompok Ilmiah SMKN 1 Purbalingga" width="5%">
            </div>
            <div class="row justify-content-center">
              <h6>SMKN 1 Purbalingga</h6>
            </div>
          </div>

        </div>
      </section> 
    </main>
    

    <footer class="footer footer-dark">
        <div class="footer-copy">
          <div class="row">
            <div class="col-12">
              <p>All © Trigger_Team All Rights Reserved.</p>
            </div>
          </div> 
        </div>
      </footer>
    
    <script src="<?= base_url('assets/') ?>js/jquery-3.2.1.min.js"></script>
    <script src="<?= base_url('assets/') ?>js/jquery-migrate-3.0.0.min.js"></script>
    <script src="<?= base_url('assets/') ?>js/jquery.parallax-scroll.js"></script>
    <script src="<?= base_url('assets/') ?>plugin/appear/jquery.appear.js"></script>
    <script src="<?= base_url('assets/') ?>plugin/bootstrap/js/popper.min.js"></script>
    <script src="<?= base_url('assets/') ?>plugin/bootstrap/js/bootstrap.js"></script>
    <script src="<?= base_url('assets/') ?>plugin/particles/particles.min.js"></script>
    <script src="<?= base_url('assets/') ?>plugin/particles/particles-app.js"></script>
    <script src="<?= base_url('assets/') ?>js/custom.js"></script>

  </body>
</html>