<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {
    public function login()
    {
        if($this->session->logged_in) redirect();

        $this->form_validation->set_rules('username', 'Username', 'required|trim');
        $this->form_validation->set_rules('password', 'Password', 'required|trim');
        if(!$this->form_validation->run()) {
            $this->load->view('pages/login');
        } else {
            $this->load->model('Auth_model', 'auth');
            $user = $this->auth->getUserByUsername($this->input->post('username'));

            if($user) {
                if(password_verify($this->input->post('password'), $user['password'])) {
                    $this->session->set_userdata('logged_in', true);
                    redirect();
                } else {
                    $this->session->set_flashdata('login_message', '<script>swal("Warning!", "Wrong password!", "warning")</script>');                    
                }
            } else {
                $this->session->set_flashdata('login_message', '<script>swal("Warning!", "No user were found!", "warning")</script>');
            }

            redirect('login');
        }
    }

    public function logout()
    {
        $this->session->unset_userdata('logged_in');
        redirect('login');
    }
}