<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Trigger extends CI_Controller {
    public function __construct() {
        parent::__construct();
        if(!$this->session->logged_in) redirect('login');
    }
    
    public function index()
    {
        $this->load->model('Trigger_model', 'trigger');
        $triggers = $this->trigger->getTrigger();
        $this->load->view('pages/home', ['triggers' => $triggers]);
    }

    public function detail($id)
    {
        $this->load->model('Trigger_model', 'trigger');
        
        $data['trigger'] = $this->trigger->getTriggerById($id)[0];
        $data['dirs'] = [
            ['id' => 'n', 'label' => 'Sisi Utara'],
            ['id' => 'e', 'label' => 'Sisi Timur'],
            ['id' => 'w', 'label' => 'Sisi Barat'],
            ['id' => 's', 'label' => 'Sisi Selatan']
        ];
        $data['states'] = [
            ['id' => 'ramai', 'label' => 'Ramai'],
            ['id' => 'sepi', 'label' => 'Sepi']
        ];
        
        $this->load->view('pages/control', $data);
    }

    public function setTime($dir, $id)
    {
        if($this->input->post('time') != null) {
            $this->load->model('Time_model', 'time');
            $data['time_' . $dir] = $this->input->post('time') * 1000;
            if($data['time_' . $dir]) {
                $this->time->updateTime($data, $id);
            }
        }

        redirect('trigger/detail/' . $id);
    }

    public function setTauto($dir, $id)
    {
        if($this->input->post('tauto') != null) {
            $this->load->model('Tauto_model', 'tauto');
            $data['tauto_' . $dir] = $this->input->post('tauto') * 1000;
            if($data['tauto_' . $dir]) {
                $this->tauto->updateTauto($data, $id);
            }
        }

        redirect('trigger/detail/' . $id);
    }

    public function setSauto($state, $id)
    {
        if($this->input->post('sauto') != null) {
            $this->load->model('Tauto_model', 'tauto');
            $data['t' . $state] = $this->input->post('sauto') * 1000;
            if($data['t' . $state]) {
                $this->tauto->updateTauto($data, $id);
            }
        }

        redirect('trigger/detail/' . $id);
    }

}