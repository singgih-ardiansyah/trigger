<?php
defined('BASEPATH') OR exit('No direct script access allowed');

header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE, OPTIONS");

require APPPATH . 'libraries/REST_Controller.php';
require APPPATH . 'libraries/Format.php';

use Restserver\Libraries\REST_Controller;

class Trigger extends REST_Controller {

    function __construct() {
        parent::__construct();
        $this->verify_request();
        
        $this->load->model('Trigger_model', 'trigger');
        $this->load->model('Time_model', 'time');
        $this->load->model('Tauto_model', 'tauto');
        $this->load->model('State_model', 'state');
    }


    private function verify_request() {
        $this->load->helper(['jwt', 'authorization']);
        $this->load->model('Token_model', 'token');

    	// Get all headers
    	$headers = $this->input->request_headers();

    	if(isset($headers['user_id']) && isset($headers['Authorization'])) {
    		$user_id = $headers['user_id'];
	    	$token = $headers['Authorization'];

	    	// Check token in database
	    	$tokenExist = $this->token->getToken($user_id, $token);

	    	if($tokenExist > 0) {
		    	try {
		    		// Validate Token
		    		$data = AUTHORIZATION::validateToken($token);

		    		if($data) {
		    			// Check user id
		    			if($data->user_id == $user_id) {
		    				if(time() > $data->expired_at) {
						    	$this->response(['message' => 'This token has been expired!'], REST_Controller::HTTP_BAD_REQUEST);
		    				}
		    			} else {
					    	$this->response(['message' => 'Wrong token!'], REST_Controller::HTTP_BAD_REQUEST);
		    			}
		    		} else {
				    	$this->response(['message' => 'Invalid token!'], REST_Controller::HTTP_BAD_REQUEST);
		    		}
		    	} catch (Exception $e) {
			    	$this->response(['message' => 'Invalid token!'], REST_Controller::HTTP_BAD_REQUEST);
		    	}
	    	} else {
		    	$this->response(['message' => "Wrong token!"], REST_Controller::HTTP_BAD_REQUEST);
	    	}
    	} else {
	    	$this->response(['message' => 'Unauthorized!'], REST_Controller::HTTP_BAD_REQUEST);
    	}
    }

    public function index_get() {
        if($this->get('id') != null) {
            $data = $this->trigger->getTriggerById($this->get('id'));
        } else {
            $data = $this->trigger->getTrigger($this->get('limit'), $this->get('start'), $this->get('keyword'));
        }

        if($data){
            $this->response(['data' => $data], REST_Controller::HTTP_OK);
        } else {
            $this->response(['data' => []], REST_Controller::HTTP_OK);
        }
    }

    public function index_post() {
        if($this->post('location') != null){
            $data["location"] = $this->post("location");
            $data["url"] = $this->post("url") != null ? $this->post("url") : "http://www.google.com/maps";
            $data["automation"] = $this->post("automation") != null ? $this->post("automation") : 0;
            $data["description"] = $this->post("description") != null ? $this->post("description") : "Belum ada keterangan";

            // Insert Traffic Light
            $status = $this->trigger->addTrigger($data);

            if($status > 0){
                $tl_id = $this->db->insert_id();

                // Insert Default Time
                $time['tl_id'] = $tl_id;
                $time['time_n'] = '15000';
                $time['time_e'] = '15000';
                $time['time_w'] = '15000';
                $time['time_s'] = '15000';
                $time_status = $this->time->addTime($time);

                // Insert Default State
                $state['tl_id'] = $tl_id;
                $state['state_n'] = 'normal';
                $state['state_e'] = 'normal';
                $state['state_w'] = 'normal';
                $state['state_s'] = 'normal';
                $state_status = $this->state->addState($state);

                // Insert Default Tauto
                $tauto['tl_id'] = $tl_id;
                $tauto['tauto_n'] = '15000';
                $tauto['tauto_e'] = '15000';
                $tauto['tauto_w'] = '15000';
                $tauto['tauto_s'] = '15000';
                $tauto['tramai'] = '10000';
                $tauto['tsepi'] = '10000';
                $tauto_status = $this->tauto->addTauto($tauto);

                $this->response([
                    'message' => 'Berhasil menambah data',
                    'time' => $time_status > 0 ? 'OK' : 'Failed',
                    'state' => $state_status > 0 ? 'OK' : 'Failed',
                    'tauto' => $tauto_status > 0 ? 'OK' : 'Failed'
                ], REST_Controller::HTTP_OK);
            } else {
                $this->response([
                    'message' => 'Failed to insert data.'
                ], REST_Controller::HTTP_BAD_REQUEST);
            }
        } else {
            $this->response([
                'message' => 'Please add the location!'
            ], REST_Controller::HTTP_BAD_REQUEST);
        }

    }

    public function index_put() {
        if($this->put("id") != null) {
            $data = [];
            
            if($this->put("location") != null) $data["location"] = $this->put("location");
            if($this->put("url") != null) $data["url"] = $this->put("url");
            if($this->put("automation") != null) $data["automation"] = $this->put("automation");
            if($this->put("description") != null) $data["description"] = $this->put("description");
            
            $status = $this->trigger->updateTrigger($data, $this->put('id'));
            
            if($status > 0) {
                $this->response([
                    'status' => TRUE,
                    'message' => 'Success update data.'
                ], REST_Controller::HTTP_OK);
            } else if($status == 0) {
                $this->response([
                    'status' => TRUE,
                    'message' => 'No row affected.'
                ], REST_Controller::HTTP_OK);
            } else {
                $this->response([
                    'status' => FALSE,
                    'message' => 'Failed to update data.'
                ], REST_Controller::HTTP_BAD_REQUEST);
            }
        } else {
            $this->response([
                'status' => FALSE,
                'message' => 'Please enter an id!'
            ], REST_Controller::HTTP_BAD_REQUEST);
        }
    }

    public function index_delete() {
        if($this->delete('id') != null) {
            // Delete Tauto
            $tauto_status = $this->tauto->deleteTauto($this->delete('id'));

            // Delete State
            $state_status = $this->state->deleteState($this->delete('id'));

            // Delete Time
            $time_status = $this->time->deleteTime($this->delete('id'));

            // Delete Trigger
            $status = $this->trigger->deleteTrigger($this->delete('id'));

            if($status > 0){
                $this->response([
                    'message' => 'Success delete data.',
                    'time' => $time_status > 0 ? 'OK' : 'Failed',
                    'state' => $time_status > 0 ? 'OK' : 'Failed',
                    'tauto' => $time_status > 0 ? 'OK' : 'Failed'
                ], REST_Controller::HTTP_OK);
            } else {
                $this->response([
                    'message' => 'Failed to delete data.',
                    'time' => $time_status > 0 ? 'OK' : 'Failed',
                    'state' => $time_status > 0 ? 'OK' : 'Failed',
                    'tauto' => $time_status > 0 ? 'OK' : 'Failed'
                ], REST_Controller::HTTP_BAD_REQUEST);
            }
        } else {
            $this->response([
                'status' => FALSE,
                'message' => 'Please add an id!'
            ], REST_Controller::HTTP_BAD_REQUEST);
        }
    }

    public function time_put()
    {
        if($this->put("id") != null) {
            $data = [];
            
            if($this->put("time_n") != null) $data["time_n"] = $this->put("time_n");
            if($this->put("time_e") != null) $data["time_e"] = $this->put("time_e");
            if($this->put("time_w") != null) $data["time_w"] = $this->put("time_w");
            if($this->put("time_s") != null) $data["time_s"] = $this->put("time_s");
            
            $status = $this->time->updateTime($data, $this->put('id'));
            
            if($status > 0) {
                $this->response([
                    'message' => 'Success update time.'
                ], REST_Controller::HTTP_OK);
            } else if($status == 0) {
                $this->response([
                    'message' => 'No row affected.'
                ], REST_Controller::HTTP_OK);
            } else {
                $this->response([
                    'message' => 'Failed to update time.'
                ], REST_Controller::HTTP_BAD_REQUEST);
            }
        } else {
            $this->response([
                'status' => FALSE,
                'message' => 'Please enter an id!'
            ], REST_Controller::HTTP_BAD_REQUEST);
        }
    }

    public function tauto_put()
    {
        if($this->put("id") != null) {
            $data = [];
            
            if($this->put("tauto_n") != null) $data["tauto_n"] = $this->put("tauto_n");
            if($this->put("tauto_e") != null) $data["tauto_e"] = $this->put("tauto_e");
            if($this->put("tauto_w") != null) $data["tauto_w"] = $this->put("tauto_w");
            if($this->put("tauto_s") != null) $data["tauto_s"] = $this->put("tauto_s");
            if($this->put("tramai") != null) $data["tramai"] = $this->put("tramai");
            if($this->put("tsepi") != null) $data["tsepi"] = $this->put("tsepi");
            
            $status = $this->tauto->updateTauto($data, $this->put('id'));
            
            if($status > 0) {
                $this->response([
                    'message' => 'Success update tauto.'
                ], REST_Controller::HTTP_OK);
            } else if($status == 0) {
                $this->response([
                    'message' => 'No row affected.'
                ], REST_Controller::HTTP_OK);
            } else {
                $this->response([
                    'message' => 'Failed to update tauto.'
                ], REST_Controller::HTTP_BAD_REQUEST);
            }
        } else {
            $this->response([
                'status' => FALSE,
                'message' => 'Please enter an id!'
            ], REST_Controller::HTTP_BAD_REQUEST);
        }
    }

    public function state_put()
    {
        if($this->put("id") != null) {
            $data = [];
            
            if($this->put("state_n") != null) $data["state_n"] = $this->put("state_n");
            if($this->put("state_e") != null) $data["state_e"] = $this->put("state_e");
            if($this->put("state_w") != null) $data["state_w"] = $this->put("state_w");
            if($this->put("state_s") != null) $data["state_s"] = $this->put("state_s");
            
            $status = $this->state->updateState($data, $this->put('id'));
            
            if($status > 0) {
                $this->response([
                    'message' => 'Success update state.'
                ], REST_Controller::HTTP_OK);
            } else if($status == 0) {
                $this->response([
                    'message' => 'No row affected.'
                ], REST_Controller::HTTP_OK);
            } else {
                $this->response([
                    'message' => 'Failed to update state.'
                ], REST_Controller::HTTP_BAD_REQUEST);
            }
        } else {
            $this->response([
                'status' => FALSE,
                'message' => 'Please enter an id!'
            ], REST_Controller::HTTP_BAD_REQUEST);
        }
    }

}