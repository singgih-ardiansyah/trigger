<?php
defined('BASEPATH') OR exit('No direct script access allowed');

header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Methods: POST, OPTIONS");

require APPPATH . 'libraries/REST_Controller.php';
require APPPATH . 'libraries/Format.php';

use Restserver\Libraries\REST_Controller;

class Auth extends REST_Controller {
    public function login_post() {
        $this->load->helper(['jwt', 'authorization']);
        $this->load->model('Auth_model', 'auth');
		$this->load->model('Token_model', 'token');
		
    	if($this->post('username') && $this->post('password')) {
    		$username = $this->post('username');
    		$password = $this->post('password'); // 'ADMTRIGGER'

    		// Check user in database
    		$user = $this->auth->getUserByUsername($username);
    		
    		if($user) {
    			if(password_verify($password, $user['password'])) {
    				// Generate Token
    				$tokenData['user_id'] = $user['user_id'];
    				$tokenData['username'] = $user['username'];
    				$tokenData['expired_at'] = time() + (60*60*24);
    				$token = AUTHORIZATION::generateToken($tokenData);

    				// Delete previous token if exist
    				$this->token->deleteToken($user['user_id']);

    				// Insert new token to database
    				$status = $this->token->insertToken(['user_id' => $user['user_id'], 'token' => $token]);

    				if($status) {
	    				// Set Output
	    				$data['user_id'] = $user['user_id'];
	    				$data['username'] = $user['username'];
	    				$data['token'] = $token;
	    				$data['token_expired'] = date("H:i:s, j F Y", $tokenData['expired_at']);
    					$data['message'] = 'Token successfully created!';
			    		$response = REST_Controller::HTTP_OK;
    				} else {
    					$data['message'] = 'Failed to create token!';
			    		$response = REST_Controller::HTTP_BAD_REQUEST;
    				}
    			} else {
	    			$data = ['message' => "Wrong password!"];
		    		$response = REST_Controller::HTTP_BAD_REQUEST;
    			}
    		} else {
    			$data = ['message' => 'User not found!'];
	    		$response = REST_Controller::HTTP_BAD_REQUEST;
    		}
    	} else {
    		$data = ['message' => 'Missing parameters!'];
    		$response = REST_Controller::HTTP_BAD_REQUEST;
    	}
    	$this->response($data, $response);
    }
}