<?php

header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Methods: GET, OPTIONS");

use Restserver\Libraries\REST_Controller;
defined('BASEPATH') OR exit('No direct script access allowed');

require APPPATH . 'libraries/REST_Controller.php';
require APPPATH . 'libraries/Format.php';

class Client extends REST_Controller {
    public function index_get() {
        $this->load->model('Trigger_model', 'trigger');

        if($this->get('id') != null) {
            $data = $this->trigger->getTriggerById($this->get('id'));
        } else {
            $data = $this->trigger->getTrigger($this->get('limit'), $this->get('start'), $this->get('keyword'));
        }

        if($data){
            $this->response(['data' => $data], REST_Controller::HTTP_OK);
        } else {
            $this->response(['data' => []], REST_Controller::HTTP_OK);
        }
    }

    public function state_get()
    {
        $this->load->model('State_model', 'state');

        if($this->get("id") != null) {
            $data = [];
            
            if($this->get("state_n") != null) $data["state_n"] = $this->get("state_n");
            if($this->get("state_e") != null) $data["state_e"] = $this->get("state_e");
            if($this->get("state_w") != null) $data["state_w"] = $this->get("state_w");
            if($this->get("state_s") != null) $data["state_s"] = $this->get("state_s");
            
            $status = $this->state->updateState($data, $this->get('id'));
            
            if($status > 0) {
                $this->response([
                    'message' => 'Success update state.'
                ], REST_Controller::HTTP_OK);
            } else if($status == 0) {
                $this->response([
                    'message' => 'No row affected.'
                ], REST_Controller::HTTP_OK);
            } else {
                $this->response([
                    'message' => 'Failed to update state.'
                ], REST_Controller::HTTP_BAD_REQUEST);
            }
        } else {
            $this->response([
                'status' => FALSE,
                'message' => 'Please enter an id!'
            ], REST_Controller::HTTP_BAD_REQUEST);
        }
    }
}