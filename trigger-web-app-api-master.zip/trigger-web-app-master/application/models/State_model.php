<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class State_model extends CI_Model {

    public function addState($data) {
        $this->db->insert('state', $data);
        return $this->db->affected_rows();
    }

    public function updateState($data, $tl_id) {
        $this->db->update('state', $data, ['tl_id' => $tl_id]);
        return $this->db->affected_rows();
    }

    public function deleteState($tl_id) {
        $this->db->delete('state', ['tl_id' => $tl_id]);
        return $this->db->affected_rows();
    }

}