<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Tauto_model extends CI_Model {

    public function addTauto($data) {
        $this->db->insert('tauto', $data);
        return $this->db->affected_rows();
    }

    public function updateTauto($data, $tl_id) {
        $this->db->update('tauto', $data, ['tl_id' => $tl_id]);
        return $this->db->affected_rows();
    }

    public function deleteTauto($tl_id) {
        $this->db->delete('tauto', ['tl_id' => $tl_id]);
        return $this->db->affected_rows();
    }

}