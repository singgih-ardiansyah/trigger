<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Trigger_model extends CI_Model {

    public function getTrigger($limit = null, $start = 0, $keyword = null) {
        if($keyword != null){
            $this->db->like('location', $keyword);
            $this->db->or_like('description', $keyword);
        }
        $this->db->join('time', 'traffic_light.id = time.tl_id');
        $this->db->join('tauto', 'traffic_light.id = tauto.tl_id');
        $this->db->join('state', 'traffic_light.id = state.tl_id');
        $this->db->select('id, location, url, automation, description, time_n, time_e, time_w, time_s, tauto_n, tauto_e, tauto_w, tauto_s, tramai, tsepi, state_n, state_e, state_w, state_s');
        return $this->db->get('traffic_light', $limit, $start)->result_array();
    }

    public function getTriggerById($id) {
        $this->db->join('time', 'traffic_light.id = time.tl_id');
        $this->db->join('tauto', 'traffic_light.id = tauto.tl_id');
        $this->db->join('state', 'traffic_light.id = state.tl_id');
        $this->db->select('id, location, url, automation, description, time_n, time_e, time_w, time_s, tauto_n, tauto_e, tauto_w, tauto_s, tramai, tsepi, state_n, state_e, state_w, state_s');
        return $this->db->get_where('traffic_light', ['id' => $id])->result_array();
    }

    public function addTrigger($data) {
        $this->db->insert('traffic_light', $data);
        return $this->db->affected_rows();
    }

    public function updateTrigger($data, $id) {
        $this->db->update('traffic_light', $data, ['id' => $id]);
        return $this->db->affected_rows();
    }

    public function deleteTrigger($id) {
        $this->db->delete('traffic_light', ['id' => $id]);
        return $this->db->affected_rows();
    }

}