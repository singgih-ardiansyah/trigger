<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Time_model extends CI_Model {

    public function addTime($data) {
        $this->db->insert('time', $data);
        return $this->db->affected_rows();
    }

    public function updateTime($data, $tl_id) {
        $this->db->update('time', $data, ['tl_id' => $tl_id]);
        return $this->db->affected_rows();
    }

    public function deleteTime($tl_id) {
        $this->db->delete('time', ['tl_id' => $tl_id]);
        return $this->db->affected_rows();
    }

}