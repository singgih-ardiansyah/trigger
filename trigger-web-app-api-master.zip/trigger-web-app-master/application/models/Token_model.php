<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Token_model extends CI_Model {

	public function getToken($user_id, $token) {
		return $this->db->get_where('tokens', ['user_id' => $user_id, 'token' => $token])->num_rows();
	}

	public function insertToken($data) {
		$this->db->insert('tokens', $data);
		return $this->db->affected_rows();
	}

	public function deleteToken($user_id)
	{
		$this->db->delete('tokens', ['user_id' => $user_id]);
	}

}