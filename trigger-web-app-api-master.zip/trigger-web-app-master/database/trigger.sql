-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Nov 18, 2019 at 01:00 PM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `trigger`
--

-- --------------------------------------------------------

--
-- Table structure for table `keys`
--

CREATE TABLE `keys` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `key` varchar(255) NOT NULL,
  `level` int(2) NOT NULL,
  `ignore_limits` tinyint(1) NOT NULL DEFAULT 0,
  `is_private_key` tinyint(1) NOT NULL DEFAULT 0,
  `ip_addresses` text DEFAULT NULL,
  `date_created` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `keys`
--

INSERT INTO `keys` (`id`, `user_id`, `key`, `level`, `ignore_limits`, `is_private_key`, `ip_addresses`, `date_created`) VALUES
(1, 1, 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpZCI6IjEiLCJ1c2VybmFtZSI6ImFkbWluIiwiaWF0IjoxNTcxNTU3NjgwLCJleHAiOjE1NzE1NzU2ODB9.Pf7sDZ_u7TODOytjr2XA6CoULnwtVs0uxK0TfgkmvdE', 1, 0, 0, NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `state`
--

CREATE TABLE `state` (
  `state_id` int(11) NOT NULL,
  `tl_id` int(11) NOT NULL,
  `state_n` enum('sepi','normal','ramai') NOT NULL,
  `state_e` enum('sepi','normal','ramai') NOT NULL,
  `state_w` enum('sepi','normal','ramai') NOT NULL,
  `state_s` enum('sepi','normal','ramai') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `state`
--

INSERT INTO `state` (`state_id`, `tl_id`, `state_n`, `state_e`, `state_w`, `state_s`) VALUES
(1, 2, 'ramai', 'ramai', 'ramai', 'ramai'),
(2, 4, 'normal', 'normal', 'normal', 'normal'),
(3, 5, 'normal', 'normal', 'normal', 'normal'),
(4, 6, 'normal', 'normal', 'normal', 'normal'),
(6, 8, 'normal', 'normal', 'normal', 'normal'),
(15, 18, 'normal', 'normal', 'normal', 'normal');

-- --------------------------------------------------------

--
-- Table structure for table `tauto`
--

CREATE TABLE `tauto` (
  `tauto_id` int(11) NOT NULL,
  `tl_id` int(11) NOT NULL,
  `tauto_n` int(11) NOT NULL,
  `tauto_e` int(11) NOT NULL,
  `tauto_w` int(11) NOT NULL,
  `tauto_s` int(11) NOT NULL,
  `tramai` int(11) NOT NULL,
  `tsepi` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tauto`
--

INSERT INTO `tauto` (`tauto_id`, `tl_id`, `tauto_n`, `tauto_e`, `tauto_w`, `tauto_s`, `tramai`, `tsepi`) VALUES
(1, 2, 14000, 12000, 18000, 16000, 8000, 5000),
(2, 4, 5000, 5000, 5000, 5000, 100000, 4000),
(3, 5, 5000, 5000, 5000, 5000, 100000, 4000),
(4, 6, 5000, 5000, 5000, 5000, 100000, 4000),
(6, 8, 5000, 5000, 5000, 5000, 100000, 4000),
(15, 18, 15000, 15000, 15000, 15000, 10000, 10000);

-- --------------------------------------------------------

--
-- Table structure for table `time`
--

CREATE TABLE `time` (
  `time_id` int(11) NOT NULL,
  `tl_id` int(11) NOT NULL,
  `time_n` int(11) NOT NULL,
  `time_e` int(11) NOT NULL,
  `time_w` int(11) NOT NULL,
  `time_s` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `time`
--

INSERT INTO `time` (`time_id`, `tl_id`, `time_n`, `time_e`, `time_w`, `time_s`) VALUES
(1, 2, 15000, 16000, 20000, 13000),
(2, 4, 16000, 13000, 14000, 12000),
(3, 5, 15000, 15000, 15000, 15000),
(4, 6, 15000, 15000, 15000, 15000),
(6, 8, 15000, 15000, 15000, 15000),
(15, 18, 15000, 17000, 13000, 22000);

-- --------------------------------------------------------

--
-- Table structure for table `tokens`
--

CREATE TABLE `tokens` (
  `token_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `token` varchar(512) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tokens`
--

INSERT INTO `tokens` (`token_id`, `user_id`, `token`) VALUES
(19, 1, 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiMSIsInVzZXJuYW1lIjoiYWRtaW4iLCJleHBpcmVkX2F0IjoxNTczNDQ5ODA2fQ.y8lBt3NshEyv9oziSzY8vSbQc3eWVg7OvwF5_jR5uBw');

-- --------------------------------------------------------

--
-- Table structure for table `traffic_light`
--

CREATE TABLE `traffic_light` (
  `id` int(11) NOT NULL,
  `location` varchar(50) NOT NULL,
  `url` varchar(255) NOT NULL,
  `automation` tinyint(1) NOT NULL,
  `description` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `traffic_light`
--

INSERT INTO `traffic_light` (`id`, `location`, `url`, `automation`, `description`) VALUES
(2, 'Perempatan Banteng', 'https://www.google.com/maps/@-7.3790531,109.3582874,21z', 1, 'Lorem ipsum dolor sit amet'),
(4, 'Perempatan Sirongge', 'http://maps.google.com', 0, 'lorem ipsum'),
(5, 'Perempatan Walik', 'http://maps.google.com', 0, 'lorem ipsum'),
(6, 'Perempatan Kalimanah', 'http://maps.google.com', 0, 'Belum ada keterangan.'),
(8, 'Perempatan Kalikabong', 'http://maps.google.com', 0, 'Belum ada keterangan.'),
(18, 'Perempatan Bancar', 'http://www.google.com/maps', 0, 'Belum ada keterangan');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `password`) VALUES
(1, 'admin', '$2y$10$2FrvaLMjZc18MCFoTuCyWOjMIT5Wj0ZZEsoMp8u.PLXI70Fyajn.u');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `keys`
--
ALTER TABLE `keys`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `state`
--
ALTER TABLE `state`
  ADD PRIMARY KEY (`state_id`),
  ADD UNIQUE KEY `tl_id` (`tl_id`);

--
-- Indexes for table `tauto`
--
ALTER TABLE `tauto`
  ADD PRIMARY KEY (`tauto_id`),
  ADD UNIQUE KEY `tl_id` (`tl_id`);

--
-- Indexes for table `time`
--
ALTER TABLE `time`
  ADD PRIMARY KEY (`time_id`),
  ADD UNIQUE KEY `tl_id` (`tl_id`);

--
-- Indexes for table `tokens`
--
ALTER TABLE `tokens`
  ADD PRIMARY KEY (`token_id`);

--
-- Indexes for table `traffic_light`
--
ALTER TABLE `traffic_light`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `keys`
--
ALTER TABLE `keys`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `state`
--
ALTER TABLE `state`
  MODIFY `state_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `tauto`
--
ALTER TABLE `tauto`
  MODIFY `tauto_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `time`
--
ALTER TABLE `time`
  MODIFY `time_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `tokens`
--
ALTER TABLE `tokens`
  MODIFY `token_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `traffic_light`
--
ALTER TABLE `traffic_light`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `keys`
--
ALTER TABLE `keys`
  ADD CONSTRAINT `keys_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `state`
--
ALTER TABLE `state`
  ADD CONSTRAINT `state_ibfk_1` FOREIGN KEY (`tl_id`) REFERENCES `traffic_light` (`id`);

--
-- Constraints for table `tauto`
--
ALTER TABLE `tauto`
  ADD CONSTRAINT `tauto_ibfk_1` FOREIGN KEY (`tl_id`) REFERENCES `traffic_light` (`id`);

--
-- Constraints for table `time`
--
ALTER TABLE `time`
  ADD CONSTRAINT `time_ibfk_1` FOREIGN KEY (`tl_id`) REFERENCES `traffic_light` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
